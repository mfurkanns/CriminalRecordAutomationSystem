/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

/**
 *
 * @author Ali Asaf
 */
public class main {
    public static void main(String[] args) {
        AnaEkran ekran=new AnaEkran();
        ekran.setVisible(true);
       // VeriTabani vt=new VeriTabani();
       // System.out.println(vt.kullaniciVarmi("mfurkan","12345678"));
        //System.out.println(vt.kullanici("aliasaf","12345678"));
    }
    
}
