/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

/**
 *
 * @author Ali Asaf
 */
public class Insan {
    
    
	public String İsim;
	public String Soyİsim;
	public String TcNo;
	public String DoğumTarih;
	public String DoğumYeri;
	public String Cinsiyet;
	public String BabaAdı;
	public String AnneAdı;
	public String CezaiDurum;
	public String SabıkaKaydı1;
	public String SabıkaKaydıTarih1;
	public String SabıkaKaydı2;
	public String SabıkaKaydıTarih2;
	public String SabıkaKaydı3;
	public String SabıkaKaydıTarih3;
	public String SabıkaKaydı4;
	public String SabıkaKaydıTarih4;
	public String SabıkaKaydı5;
	public String SabıkaKaydıTarih5;
        
        
    
}
